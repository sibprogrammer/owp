<?php
/** Zend_Exception */
require_once 'Zend/Exception.php';

class Zend_Dom_Exception extends Zend_Exception
{
}
